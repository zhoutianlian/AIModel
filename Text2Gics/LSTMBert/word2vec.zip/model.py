from settings import *
import os

if not USE_GPU:
	os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
	import tensorflow as tf
else:
	os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
	import tensorflow as tf
	gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
	for gpu in gpus:
		tf.config.experimental.set_memory_growth(gpu, True)

import keras_bert
import pandas as pd
from tensorflow.keras.models import Model
from tensorflow.keras.layers import *
from config import bert_config, bert_model, gics4
from tensorflow.keras.optimizers import Nadam
from tensorflow.keras.regularizers import l1
import matplotlib.pyplot as plt


class IndustryClassifierModel:
	def __init__(self):
		self._gics4_count = len(gics4)
		self._vec_length = VEC_LENGTH
		self._bert_length = BERT_LENGTH
		self._bert_width = BERT_WIDTH
		self._bert_shape = None
		self._build_bert_model()

	def _bert_reducer(self, level=0):
		vec_input = Input(shape=self._bert_shape, name='RedInput%d' % level)
		mod = vec_input[:, :self._bert_length, :self._bert_width]
		mod = Flatten(name='RedFlat%d' % level)(mod)
		return Model(vec_input, mod, name='RedMod%d' % level)

	def _build_vector_model(self, sector):
		input_1 = Input(shape=(None,), name='Input%d1' % sector)
		input_2 = Input(shape=(None,), name='Input%d2' % sector)
		vec = self._bert([input_1, input_2])
		mod = vec[:, :self._bert_length, :self._bert_width]
		mod = Flatten(name='RedFlat%d' % sector)(mod)
		return (input_1, input_2), Model([input_1, input_2], mod)([input_1, input_2])

	def _build_bert_model(self):
		self._bert = keras_bert.load_trained_model_from_checkpoint(bert_config, bert_model, trainable=TRAIN_BERT)
		self._bert_shape = self._bert.output.shape[1:]

		(input_11, input_12), sec_1 = self._build_vector_model(1)
		(input_21, input_22), sec_2 = self._build_vector_model(2)
		(input_31, input_32), sec_3 = self._build_vector_model(3)
		(input_41, input_42), sec_4 = self._build_vector_model(4)

		embd = Embedding(input_dim=50000, output_dim=16)

		embd_11 = embd(input_11)
		embd_21 = embd(input_21)
		embd_31 = embd(input_31)
		embd_41 = embd(input_41)
		ed = Dense(64, activation='relu')(Flatten()(concatenate([embd_11, embd_21, embd_31, embd_41])))

		mod = Concatenate(name='Concat')([sec_1, sec_2, sec_3, sec_4, ed])
		mod = BatchNormalization(name='BN')(mod)
		mod = Dense(64, activation='relu', name='Dense1')(mod)
		mod = Dropout(0.2, name='Drop1')(mod)
		mod = Dense(64, activation='relu', name='Dense2')(mod)
		mod = Dropout(0.2, name='Drop2')(mod)
		out = Dense(self._gics4_count,
		            activity_regularizer=l1(),
		            use_bias=False,
		            name='Dense3')(mod)

		self._model = Model([input_11, input_12,
		                     input_21, input_22,
		                     input_31, input_32,
		                     input_41, input_42],
		                    out,
		                    name='IndClsMod')
		self._model.summary()

	@staticmethod
	def review(log_path, print_data = False):
		train_review = pd.read_csv(log_path + '/train_history.csv', index_col=0)
		valid_review = pd.read_csv(log_path + '/valid_history.csv', index_col=0)
		if print_data:
			print(train_review)
			print(valid_review)

		plt.close()
		fig, ax = plt.subplots(figsize=(16, 9))
		ax.plot(train_review.index, train_review['loss'], label='train')
		ax.plot(valid_review.index, valid_review['loss'], label='valid')
		ax.set_xlabel('Batches')
		ax.set_ylabel('Loss')
		ax.set_title('Loss')
		ax.legend()
		fig.savefig(log_path + '/loss.png')

		plt.close()
		fig, axes = plt.subplots(1, 2, figsize=(16, 9))
		fig.suptitle('Accuracy')
		for j in range(2):
			for i in range(4):
				axes[j].plot(train_review.index, train_review['acc%d' % (i+1)], label='acc%d' % (i+1))
			axes[j].set_ylim(0, 1)
			axes[j].set_xlabel('Batches')
			axes[j].set_ylabel('Accuracy')
			axes[j].legend()

		axes[0].set_title('Train Set')
		axes[1].set_title('Valid Set')

		fig.savefig(log_path + '/acc.png')
		plt.close()

	def train(self, path: str, generator: any, train: str, valid: str, loss, metrics=None, max_len: dict = None,
	          optimizer=Nadam(),
	          batches: int = 50000,
	          batch_size: int = 32,
	          start: int = 0,
	          valid_batches: int = 10,
	          save_period: int = 500,
	          eval_period: int = 50,
	          exchange_frequency: int = 0,
	          ):

		self._model.compile(optimizer, loss, metrics)
		train_data = generator(train, max_len, self._vec_length, exchange_frequency=exchange_frequency)
		next(train_data)
		valid_data = generator(valid, max_len, self._vec_length, exchange_frequency=exchange_frequency)
		next(valid_data)

		train_log = list()
		epoch_log = list()

		log_mode = 'w'
		x_test, y_test, y_id_test = train_data.send(batch_size)
		print('Shape: X = %s  y = %s' % (x_test[0].shape, y_test.shape))

		path = 'save/' + path
		if not os.path.exists(path):
			os.makedirs(path + '/weights')

		if start > 0:
			try:
				self._model.load_weights(path + '/weights/model%08d.h5' % start)
				print('Load weights from %08d model!' % start)
				log_mode = 'a'
			except Exception as err:
				print(err)
				raise FileNotFoundError('Cannot find model %08d' % start)

		for b in range(start, start + batches):
			x_train, y_train, y_id_train = train_data.send(batch_size)
			result = self._model.train_on_batch(x_train, y_train)
			train_log.append(result)
			epoch_log.append(b+1)
			print('\rBatch %04d  ' % (b+1), end='')
			print('loss = %.4f  acc1 = %.4f  acc2 = %.4f  acc3 = %.4f  acc4 = %.4f  ' % tuple(result), end='')

			if (b+1) % eval_period == 0:
				print('\n*** Batch %04d - %04d Summary ***' % (epoch_log[0], epoch_log[-1]))
				train_df = pd.DataFrame(train_log, columns=['loss', 'acc1', 'acc2', 'acc3', 'acc4'], index=epoch_log)
				train_df.to_csv(path + '/train_history.csv', header=(log_mode=='w'), mode=log_mode)
				train_summary = train_df.mean()

				evaluations = list()
				for j in range(valid_batches):
					x_valid, y_valid, y_id_valid = valid_data.send(batch_size)
					eva_result = self._model.evaluate(x_valid, y_valid, verbose=0)
					evaluations.append(eva_result)

				valid_df = pd.DataFrame(evaluations, columns=['loss', 'acc1', 'acc2', 'acc3', 'acc4'])
				valid_summary = valid_df.mean().rename(b+1)
				valid_summary.to_frame().T.to_csv(path + '/valid_history.csv',
				                                  header=(log_mode=='w'), mode=log_mode)

				summary_df = pd.DataFrame([train_summary, valid_summary], index=['train', 'valid'])
				print(summary_df)
				print('*' * 33)

				train_log = list()
				epoch_log = list()
				log_mode = 'a'

				self.review(path, False)

				if (b+1) % save_period == 0:
					self._model.save_weights(path + '/weights/model%08d.h5' % (b+1))
					print('Save model %08d!' % (b+1))

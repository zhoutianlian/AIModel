from model import IndustryClassifierModel
from data import data_generator
from utils import gics_loss, gics_acc
from tensorflow.keras.optimizers import *


my_model = IndustryClassifierModel()

train_path = 'data/data_train.csv'
valid_path = 'data/data_valid.csv'
max_length = {'brief': 5, 'business_scope': 6, 'company_name': 1, 'main_business': 2}

my_model.train('simple_bert',
               data_generator,
               train_path,
               valid_path,
               max_len=max_length,
               optimizer=Nadam(),
               loss=gics_loss,
               metrics=gics_acc,
               batch_size=8,
               start=0,
               exchange_frequency=0,
               batches=5000,
               save_period=500,
               eval_period=25,
               )

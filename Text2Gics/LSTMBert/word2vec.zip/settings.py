USE_GPU = False
TRAIN_BERT = True

LOSS_WEIGHTS = (1, 1, 1, 1)
VEC_LENGTH = 512
# BERT_LENGTH = 128
BERT_LENGTH = 64
# BERT_WIDTH = 64
BERT_WIDTH = 16

if USE_GPU and TRAIN_BERT:
	raise Warning('Computer would possibly raise OOM!')

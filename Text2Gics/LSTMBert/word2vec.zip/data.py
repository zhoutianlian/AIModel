from tensorflow.keras.utils import to_categorical
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import pandas as pd
import codecs
from keras_bert import Tokenizer
from config import gics4, vocab
from glob import glob


__all__ = ['data_generator', 'pre_treat']
text_cols = ['brief', 'business_scope', 'company_name', 'main_business']
cat_num = len(gics4)
token_dict = {}

with codecs.open(vocab, 'r', 'utf8') as reader:
    for line in reader:
        token = line.strip()
        token_dict[token] = len(token_dict)
tokenizer = Tokenizer(token_dict)


def pre_treat(text):
    for s in ['，', '：', ';', '；', '!', '！', '?', '？', '…']:
        text = text.replace(s, '。')
    if '。。' in text:
        text = text.replace('。。', '。')
    return text


def get_token(max_len=np.inf):
    def to_token(text):
        sentence = text.split('。')
        if len(sentence) > max_len:
            sentence = sentence[:max_len]
        text = '。'.join(sentence) + '。'
        char_vec, sent_vec = tokenizer.encode(first=text)
        return np.array(char_vec), np.array(sent_vec)
    return to_token


def random_exchanger(word_list):
    count = len(word_list)
    def exchanger(text):
        for w in word_list:
            if w in text:
                return word_list.replace(w, word_list[np.random.randint(0, count)])
        else:
            return text
    return exchanger


def exchange_generator(data, exchange_frequency):
    """
    可以交换句子的生成器
    :param data:
    :param exchange_frequency:
    :return:
    """
    random_data = None

    ex_dicts = list()
    ex_num = 0
    for ed_path in glob('exchange/*.txt'):
        word = pd.read_csv(ed_path).iloc[:, 0].to_list()
        ex_dicts.append(random_exchanger(word))
        ex_num += 1

    while True:
        batch_size = yield random_data
        random_data = list()
        for i in np.random.randint(0, cat_num, batch_size):
            industry_data = data.query('gics_code == @gics4[@i]')

            lucky = industry_data.iloc[np.random.randint(0, len(industry_data), np.random.randint(3, 10))][text_cols]
            lucky = lucky.applymap(lambda w: w.split('。'))

            # 随机次数和随机字段
            for col in np.random.randint(0, 4, np.random.randint(0, exchange_frequency)):
                host = lucky.iloc[0, col]
                s_host = np.random.randint(0, len(host))  # 主句第几句话
                row = np.random.randint(1, len(lucky))  # 客句取第几行数据
                cust = lucky.iloc[row, col]
                s_cust = np.random.randint(0, len(cust))  # 客句第几句话
                host[s_host] = cust[s_cust]  # 置换
                lucky.iloc[0, col] = host  # 填入

            host_data = lucky.iloc[0].apply(lambda w: '。'.join(w))
            host_data['gics_id'] = i
            random_data.append(host_data)
        random_data = pd.DataFrame(random_data, index=range(batch_size))
        # todo 随机置换地名、公司名
        for i in np.random.randint(0, ex_num, exchange_frequency):
            random_data[text_cols] = random_data[text_cols].applymap(ex_dicts[i])


def normal_generator(data):
    """
    简单生成器
    :param data:
    :return:
    """
    random_data = None
    data['gics_id'] = data['gics_code'].apply(lambda i: np.where(gics4==i)[0][0])

    while True:
        batch_size = yield random_data
        random_index = np.random.randint(0, len(data), batch_size)
        random_data = data.iloc[random_index]


def data_generator(data_path, max_length: dict = None, vec_length: int = 512, exchange_frequency: int = 0):
    """
    数据生成器
    :param data_path:
    :param max_length:
    :param vec_length:
    :param exchange_frequency: 同一行业下语句的交换率
    :return:
    """
    data = pd.read_csv(data_path, index_col=0, dtype={'gics_code': int})
    data = data.fillna('无')
    data[text_cols] = data[text_cols].applymap(pre_treat)
    data['company_name'] = data['company_name'].apply(lambda w: w.replace('。', ''))

    max_length = dict() if max_length is None else max_length
    for k in text_cols:
        max_length.setdefault(k, np.inf)

    x_list = None
    y_ = None
    y_id = None

    if exchange_frequency:
        # 取非0时，采取随机策略
        random_data = exchange_generator(data, exchange_frequency)
        next(random_data)
    else:
        # 取0时，采取非随机策略
        random_data = normal_generator(data)
        next(random_data)

    while True:
        batch_size = yield x_list, y_, y_id

        random_df = random_data.send(batch_size)
        random_df.to_csv('test1.csv')
        y_id = random_df['gics_id'].values
        y_ = to_categorical(y_id, cat_num, int)
        x_ = random_df[text_cols]

        x_list = list()
        for k in text_cols:
            x1, x2 = zip(*x_[k].apply(get_token(max_length[k])))
            x_list.append(pad_sequences(x1, vec_length, padding='post'))
            x_list.append(pad_sequences(x2, vec_length, padding='post'))


if __name__ == '__main__':
    dg = data_generator('data/data_train.csv', exchange_frequency=5)
    next(dg)
    y, *x = dg.send(32)
    print(y)
    print(x[0])

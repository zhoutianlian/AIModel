import pandas as pd
import matplotlib.pyplot as plt



train_review = pd.read_csv('save/simple/train_history.csv', index_col=0)
print(train_review)
valid_review = pd.read_csv('save/simple/valid_history.csv', index_col=0)
print(valid_review)

fig, ax = plt.subplots(figsize=(16, 9))
ax.plot(train_review.index, train_review['loss'], label='train')
ax.plot(valid_review.index, valid_review['loss'], label='valid')
ax.set_xlabel('Batches')
ax.set_ylabel('Loss')
ax.set_title('Loss')
ax.legend()
fig.savefig('review/loss.png')
plt.show()

plt.close()
fig, axes = plt.subplots(1, 2 ,figsize=(16, 9))
fig.suptitle('Accuracy')

axes[0].plot(train_review.index, train_review['acc1'], label='acc1')
axes[0].plot(train_review.index, train_review['acc2'], label='acc2')
axes[0].plot(train_review.index, train_review['acc3'], label='acc3')
axes[0].plot(train_review.index, train_review['acc4'], label='acc4')
axes[0].set_ylim(0, 1)
axes[0].set_xlabel('Batches')
axes[0].set_ylabel('Accuracy')
axes[0].set_title('Train Set')
axes[0].legend()

axes[1].plot(valid_review.index, valid_review['acc1'], label='acc1')
axes[1].plot(valid_review.index, valid_review['acc2'], label='acc2')
axes[1].plot(valid_review.index, valid_review['acc3'], label='acc3')
axes[1].plot(valid_review.index, valid_review['acc4'], label='acc4')
axes[1].set_ylim(0, 1)
axes[1].set_xlabel('Batches')
axes[1].set_ylabel('Accuracy')
axes[1].set_title('Valid Set')
axes[1].legend()

fig.savefig('review/acc.png')
plt.show()

